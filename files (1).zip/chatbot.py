"""ShopEasy AI Customer Support Chatbot (Python + Google Gemini API).

Concepts: system prompt, API request, multi-turn conversation history,
temperature, error handling, and a safe fallback when the answer is unknown.
"""
import os
import sys
import time

from dotenv import load_dotenv
from google import genai
from google.genai import errors, types

load_dotenv()

MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")  # change in .env if your key cannot use it
TEMPERATURE = 0.3      # low = consistent, factual answers; try 0.9 to see the difference
MAX_HISTORY = 20       # keep the last 20 messages (10 exchanges) to save tokens

WELCOME = "Hello! Welcome to ShopEasy. How can I help you today?"
HUMAN_SUPPORT = "support@shopeasy.example or 1800-000-000 (Mon-Sat, 9 AM-6 PM)"
FALLBACK = f"I'm sorry, I couldn't come up with an answer. Please contact our support team at {HUMAN_SUPPORT}."

# 1. SYSTEM PROMPT: the chatbot's role, rules and the only facts it may use.
SYSTEM_PROMPT = f"""You are the ShopEasy Support Bot, a customer support representative for ShopEasy, an e-commerce company.

TONE
- Friendly, clear and professional. Keep answers short (2-5 sentences). Use simple words.
- Use the earlier messages in the conversation to understand follow-up questions such as "what about refunds?" or "how long will it take?".

COMPANY POLICY (the ONLY facts you may state)
- Orders: Customers can track orders under My Orders using the order ID. Orders can be cancelled before they are shipped.
- Payments: We accept UPI, credit/debit cards, net banking and Cash on Delivery (COD). Failed payments are usually refunded automatically in 5-7 business days.
- Delivery: Standard delivery takes 3-5 business days. Express delivery takes 1-2 business days. Delivery is free on orders above Rs. 499; otherwise the charge is Rs. 40.
- Returns: Returns are accepted within 7 days of delivery for eligible products. Customers must check the product's return eligibility before requesting a return. Items must be unused and in original packaging.
- Refunds: Refunds are issued to the original payment method within 5-7 business days after the returned item passes quality check. COD refunds go to the customer's bank account or store credit.
- Products: Product details, size and warranty information are on each product page.
- Human support: {HUMAN_SUPPORT}.

RULES
1. Use only the policy above. If you do not know something, say so honestly. NEVER invent order status, tracking details, prices, dates, discounts or policies.
2. You cannot see or look up individual orders. If asked about a specific order, ask for the order ID if it is missing, then explain how to check it under My Orders, and offer human support for anything more.
3. If you cannot resolve the issue, or the customer is angry, wants to speak to a person, or reports damage, fraud or payment problems, politely direct them to human support using the contact details above.
4. Never ask for card numbers, CVV, OTPs or passwords.
5. Stay on ShopEasy support topics. Politely decline unrelated requests and offer to help with orders, payments, delivery, returns, refunds or products.
"""

CONFIG = types.GenerateContentConfig(system_instruction=SYSTEM_PROMPT, temperature=TEMPERATURE)


def ask(client, history, user_text):
    """Send the user's message plus the whole conversation so far; return the reply.

    `history` is a list of messages that we keep and re-send on every request,
    because the API itself does not remember previous calls.
    """
    history.append(types.Content(role="user", parts=[types.Part(text=user_text)]))
    while len(history) > MAX_HISTORY:   # drop the oldest exchange (user + model)
        del history[:2]
    try:
        for attempt in range(3):        # retry briefly when the service is busy
            try:
                response = client.models.generate_content(model=MODEL, contents=history, config=CONFIG)
                break
            except errors.APIError as e:
                if e.code in (429, 503) and attempt < 2:
                    time.sleep(2 * (attempt + 1))
                    continue
                raise
        reply = (response.text or "").strip() or FALLBACK
    except Exception:
        history.pop()                   # keep history consistent: remove the unanswered message
        raise
    history.append(types.Content(role="model", parts=[types.Part(text=reply)]))
    return reply


def explain_error(e):
    """Return (message for the customer, hint for the developer)."""
    code = getattr(e, "code", None)
    customer = f"Sorry, I'm having trouble right now. Please try again in a moment, or contact {HUMAN_SUPPORT}."
    if code == 429:
        return customer, "Rate limit reached (free tier). Wait a minute and try again."
    if code in (401, 403) or "API key" in str(e):
        return customer, "The API key is missing, wrong or not allowed. Check GEMINI_API_KEY in your .env file."
    if code == 404:
        return customer, f"Model '{MODEL}' was not found. Set GEMINI_MODEL in .env to a model listed in Google AI Studio."
    return customer, f"{type(e).__name__}: {e}"


def main():
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        print("No API key found. Copy .env.example to .env and add your GEMINI_API_KEY (see README.md).")
        sys.exit(1)
    client = genai.Client(api_key=key)
    history = []

    print("=" * 52)
    print("ShopEasy Support Bot   [Online]")
    print("Type 'quit' to exit, '/reset' to start a new chat.")
    print("=" * 52)
    print(f"\nBot: {WELCOME}\n")

    while True:
        try:
            text = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBot: Thank you for contacting ShopEasy. Goodbye!")
            break
        if not text:
            print("Bot: Please type your question so I can help.\n")
            continue
        if text.lower() in ("quit", "exit", "bye"):
            print("Bot: Thank you for contacting ShopEasy. Have a great day!")
            break
        if text.lower() == "/reset":
            history.clear()
            print(f"Bot: Chat reset. {WELCOME}\n")
            continue
        if len(text) > 1000:
            print("Bot: That message is a bit long. Please shorten it to 1000 characters or less.\n")
            continue
        try:
            print(f"\nBot: {ask(client, history, text)}\n")
        except Exception as e:
            customer, hint = explain_error(e)
            print(f"\nBot: {customer}\n[developer note] {hint}\n")


if __name__ == "__main__":
    main()
