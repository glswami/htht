# ShopEasy AI Customer Support Chatbot
Python + VS Code + Google Gemini API (free tier)

## 1. Setup (Windows, VS Code)
1. Install Python 3.10+ (tick "Add Python to PATH") and VS Code with the Python extension.
2. Get a free API key: https://aistudio.google.com/apikey  -> **Create API key**.
3. In VS Code: **File > Open Folder** > `shopeasy-chatbot`, then open **Terminal > New Terminal** and run:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```
(If activation is blocked, run `Set-ExecutionPolicy -Scope Process Bypass` first.
 On Mac/Linux: `source .venv/bin/activate` and `cp .env.example .env`.)

4. Open `.env` and replace `paste_your_key_here` with your key. Never share or upload this file.
5. Run: `python chatbot.py`

## 2. Try this conversation
```
You: Where is my order?
You: What is your return policy?
You: And how long does the refund take?      <- follow-up, tests memory
You: What is the price of the iPhone 15?     <- not in policy, should NOT invent
You: I want to talk to a person              <- should give human support details
You:                                         <- empty input is handled
```

## 3. Requirements checklist
| Requirement | Where in `chatbot.py` |
|---|---|
| Welcome message | `WELCOME`, printed in `main()` |
| Answer common queries | `ask()` sends the question to the model |
| System prompt | `SYSTEM_PROMPT` + `CONFIG` |
| Conversation history | `history` list re-sent on every call (trimmed by `MAX_HISTORY`) |
| Context understanding | follow-ups work because history is sent |
| Error handling | empty/long input checks, retries, `explain_error()` |
| Fallback, no made-up answers | rule 1 in the system prompt + `FALLBACK` |
| Human support handoff | rule 3 in the system prompt |

## 4. Experiments
- **Temperature:** change `TEMPERATURE` from 0.3 to 0.9 and ask the same question 3 times.
- **System prompt:** remove rule 1 and ask for an order's delivery date; see the bot start to guess.
- **Memory:** type `/reset`, then ask "And how long does the refund take?" and compare.

## 5. Troubleshooting
- `No API key found`: check `.env` is in the same folder and has `GEMINI_API_KEY=...`.
- `404 / model not found`: set `GEMINI_MODEL` in `.env` to a model shown in Google AI Studio.
- `429`: free-tier limit reached; wait a minute.

## 6. Optional extension: structured responses
Add `response_mime_type="application/json"` to `GenerateContentConfig` and ask in the system prompt
for `{"reply": "...", "category": "orders|payments|delivery|returns|refunds|products|other", "needs_human": true|false}`,
then parse with `json.loads(response.text)`.

## Link to the Claude API
Same ideas, different SDK: Claude uses a `system` parameter, a `messages` list of `user`/`assistant`
turns that you re-send each time, and `temperature`. The code structure here transfers directly.
